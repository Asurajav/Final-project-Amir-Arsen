package kz.arsen;

import java.io.*;
import java.util.*;

public class PackageData implements Serializable {
    private String operationType;
    private Client client;
    private ArrayList<Client> clients;
    private Integer id;
    private ClientTableModel clientTableModel;
    private Books book;
    private BookTableModel bookTableModel;
    private ArrayList<Books> bookss;
    private String xxxx=null;


    ///ДЛЯ АВТОРИЗАЦИИ КЛИЕНТОВ
    private String login;
    private String password;
    private boolean infoCheckForClient;

///ЭТО ДЛЯ РЕГИСТРАЦИИ КЛИЕНТОВ
    public PackageData(String operationType, Client client) {
        this.operationType = operationType;
        this.client = client;
    }
    ///ЭТО ДЛЯ УДАЛЕНИЯ СТУДЕНТОВ ИЛИ КЛИЕНТОВ
    public PackageData(String operationType,Integer id){
        this.operationType=operationType;
        this.id=id;
    }
    ///ЭТО ДЛЯ АВТОРИЗАЦИИ
    public PackageData(String operationType,String login,String password){
        this.operationType=operationType;
        this.login=login;
        this.password=password;
    }
///ЭТО ДЛЯ ВЫВОДА ИНФОРМАЦИИ НА ТАБЛИЦУ
    public PackageData(String operationType,ClientTableModel clientTableModel){
        this.operationType=operationType;
        this.clientTableModel=clientTableModel;
    }
///ДОБАВЛЕНИЕ КНИГ
    public PackageData(String operationType, Books book) {
        this.operationType = operationType;
        this.book = book;
    }

    public PackageData(String operationType, BookTableModel bookTableModel) {
        this.operationType = operationType;
        this.bookTableModel = bookTableModel;
    }



    public PackageData(String operationType) {
        this.operationType = operationType;
    }


    public PackageData(ArrayList<Client> clients) {
        this.clients = clients;
    }

    public PackageData(ArrayList<Books> bookss, String xxxx) {
        this.bookss = bookss;
        this.xxxx = xxxx;
    }

    public PackageData(boolean infoCheckForClient) {
        this.infoCheckForClient = infoCheckForClient;
    }



    public String getOperationType() {
        return operationType;
    }

    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public ArrayList<Client> getClients() {
        return clients;
    }

    public void setClients(ArrayList<Client> clients) {
        this.clients = clients;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isInfoCheckForClient() {
        return infoCheckForClient;
    }

    public void setInfoCheckForClient(boolean infoCheckForClient) {
        this.infoCheckForClient = infoCheckForClient;
    }

    public ClientTableModel getClientTableModel() {
        return clientTableModel;
    }

    public void setClientTableModel(ClientTableModel clientTableModel) {
        this.clientTableModel = clientTableModel;
    }

    public Books getBook() {
        return book;
    }

    public void setBook(Books book) {
        this.book = book;
    }



    public BookTableModel getBookTableModel() {
        return bookTableModel;
    }

    public void setBookTableModel(BookTableModel bookTableModel) {
        this.bookTableModel = bookTableModel;
    }

    public ArrayList<Books> getBookss() {
        return bookss;
    }

    public void setBookss(ArrayList<Books> bookss) {
        this.bookss = bookss;
    }
}
