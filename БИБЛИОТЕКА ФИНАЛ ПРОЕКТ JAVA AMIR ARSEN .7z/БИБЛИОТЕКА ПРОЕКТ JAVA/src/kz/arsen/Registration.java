package kz.arsen;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Registration extends Container {


    private JLabel nameLabel;
    private JLabel surnameLabel;
    private JLabel loginLabel;
    private JLabel passwordLabel;
    private JLabel emailLabel;
    private JLabel titleLabel;


    private JTextField nameText;
    private JTextField surnameText;
    private JTextField loginText;
    private JTextField passwordText;
    private JTextField emailText;

    private JButton backButton;
    private JButton regButton;


    public Registration(){
        setSize(800,800);
        setLayout(null);


        titleLabel=new JLabel("REGISTRATION");
        titleLabel.setBounds(300,10,300,40);
        titleLabel.setFont (titleLabel.getFont ().deriveFont (40.0f));
        titleLabel.setForeground(Color.decode("#FFCC33"));
        add(titleLabel);
////name
        nameLabel=new JLabel("Name:");
        nameLabel.setFont (nameLabel.getFont ().deriveFont (20.0f));
        nameLabel.setBounds(220,60,100,40);
        nameLabel.setForeground(Color.DARK_GRAY);
        add(nameLabel);

        nameText=new JTextField();
        nameText.setBounds(320,60,200,40);
        nameText.setFont (nameText.getFont ().deriveFont (20.0f));
        nameText.setBackground(Color.DARK_GRAY);
        nameText.setForeground(Color.decode("#FFCC33"));
        nameText.setCaretColor(Color.RED);
        add(nameText);

///surname
        surnameLabel=new JLabel("Surname:");
        surnameLabel.setFont (nameLabel.getFont ().deriveFont (20.0f));
        surnameLabel.setBounds(220,110,100,40);
        surnameLabel.setForeground(Color.DARK_GRAY);
        add(surnameLabel);

        surnameText=new JTextField();
        surnameText.setBounds(320,110,200,40);
        surnameText.setFont (surnameText.getFont ().deriveFont (20.0f));
        surnameText.setBackground(Color.DARK_GRAY);
        surnameText.setForeground(Color.decode("#FFCC33"));
        surnameText.setCaretColor(Color.RED);
        add(surnameText);

///login
        loginLabel=new JLabel("Login:");
        loginLabel.setFont (loginLabel.getFont ().deriveFont (20.0f));
        loginLabel.setBounds(220,160,100,40);
        loginLabel.setForeground(Color.DARK_GRAY);
        add(loginLabel);

        loginText=new JTextField();
        loginText.setBounds(320,160,200,40);
        loginText.setFont (loginText.getFont ().deriveFont (20.0f));
        loginText.setBackground(Color.DARK_GRAY);
        loginText.setForeground(Color.decode("#FFCC33"));
        loginText.setCaretColor(Color.RED);
        add(loginText);

///password
        passwordLabel=new JLabel("Password:");
        passwordLabel.setFont (passwordLabel.getFont ().deriveFont (20.0f));
        passwordLabel.setBounds(220,210,100,40);
        passwordLabel.setForeground(Color.DARK_GRAY);
        add(passwordLabel);

        passwordText=new JTextField();
        passwordText.setBounds(320,210,200,40);
        passwordText.setFont (passwordText.getFont ().deriveFont (20.0f));
        passwordText.setBackground(Color.DARK_GRAY);
        passwordText.setForeground(Color.decode("#FFCC33"));
        passwordText.setCaretColor(Color.RED);
        add(passwordText);
///E-mail
        emailLabel=new JLabel("E-mail:");
        emailLabel.setFont (emailLabel.getFont ().deriveFont (20.0f));
        emailLabel.setBounds(220,260,100,40);
        emailLabel.setForeground(Color.DARK_GRAY);
        add(emailLabel);

        emailText=new JTextField();
        emailText.setBounds(320,260,200,40);
        emailText.setFont (emailText.getFont ().deriveFont (20.0f));
        emailText.setBackground(Color.DARK_GRAY);
        emailText.setForeground(Color.decode("#FFCC33"));
        emailText.setCaretColor(Color.RED);
        add(emailText);
///reg
        regButton=new JButton("Enter");
        regButton.setFont (regButton.getFont ().deriveFont (20.0f));
        regButton.setBounds(250,310,270,40);
        regButton.setBackground(Color.DARK_GRAY);
        regButton.setForeground(Color.decode("#FFCC33"));
        regButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               String name=nameText.getText();
               String surname=surnameText.getText();
               String login=loginText.getText();
               String password=passwordText.getText();
               String email=emailText.getText();
               if(name.equals("") || surname.equals("") || login.equals("") || password.equals("") || email.equals("")){
                   JOptionPane.showMessageDialog(Main.frame.registrationWindow,"ENTER ALL!!!");
               }else {
                   Client client=new Client(null,name,surname,login,password,email);
                   PackageData pd=new PackageData("Reg",client);
                   Main.connect(pd);
                   JOptionPane.showMessageDialog(Main.frame.registrationWindow,"SUCCESS");
               }



               nameText.setText("");
               surnameText.setText("");
               loginText.setText("");
               passwordText.setText("");
               emailText.setText("");

            }
        });
        add(regButton);

///back
        backButton=new JButton("Back");
        backButton.setFont (backButton.getFont ().deriveFont (20.0f));
        backButton.setBounds(250,360,270,40);
        backButton.setBackground(Color.DARK_GRAY);
        backButton.setForeground(Color.decode("#FFCC33"));
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Main.frame.menuWindow.setVisible(true);
                Main.frame.registrationWindow.setVisible(false);
            }
        });
        add(backButton);


    }

}
