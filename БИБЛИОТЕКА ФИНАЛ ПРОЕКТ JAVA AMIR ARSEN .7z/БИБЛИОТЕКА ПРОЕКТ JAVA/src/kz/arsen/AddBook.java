package kz.arsen;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AddBook extends Container {

    private JLabel nameLabel;
    private JLabel authorLabel;
    private JLabel ratingLabel;



    private JTextField nameText;
    private JTextField authorText;
    private JTextField ratingText;


    private JButton backButton;
    private JButton addButton;


    public AddBook(){
        setSize(500,600);
        setLayout(null);

////ИМЯ КНИГИ
        nameLabel=new JLabel("Name:");
        nameLabel.setFont (nameLabel.getFont ().deriveFont (20.0f));
        nameLabel.setBounds(220,60,100,40);
        nameLabel.setForeground(Color.DARK_GRAY);
        add(nameLabel);

        nameText=new JTextField();
        nameText.setBounds(320,60,200,40);
        nameText.setFont (nameText.getFont ().deriveFont (20.0f));
        nameText.setBackground(Color.DARK_GRAY);
        nameText.setForeground(Color.decode("#FFCC33"));
        nameText.setCaretColor(Color.RED);
        add(nameText);

///АВТОР КНИГИ
        authorLabel=new JLabel("Author:");
        authorLabel.setFont (authorLabel.getFont ().deriveFont (20.0f));
        authorLabel.setBounds(220,110,100,40);
        authorLabel.setForeground(Color.DARK_GRAY);
        add(authorLabel);

        authorText=new JTextField();
        authorText.setBounds(320,110,200,40);
        authorText.setFont (authorText.getFont ().deriveFont (20.0f));
        authorText.setBackground(Color.DARK_GRAY);
        authorText.setForeground(Color.decode("#FFCC33"));
        authorText.setCaretColor(Color.RED);
        add(authorText);

///ЖАНР КНИГИ
        ratingLabel=new JLabel("Genre:");
        ratingLabel.setFont (ratingLabel.getFont ().deriveFont (20.0f));
        ratingLabel.setBounds(220,160,100,40);
        ratingLabel.setForeground(Color.DARK_GRAY);
        add(ratingLabel);

        ratingText=new JTextField();
        ratingText.setBounds(320,160,200,40);
        ratingText.setFont (ratingText.getFont ().deriveFont (20.0f));
        ratingText.setBackground(Color.DARK_GRAY);
        ratingText.setForeground(Color.decode("#FFCC33"));
        ratingText.setCaretColor(Color.RED);
        add(ratingText);

///addButton
        addButton=new JButton("ADD");
        addButton.setFont (addButton.getFont ().deriveFont (20.0f));
        addButton.setBounds(250,310,270,40);
        addButton.setBackground(Color.DARK_GRAY);
        addButton.setForeground(Color.decode("#FFCC33"));
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name=nameText.getText();
                String author=authorText.getText();
                String rating=ratingText.getText();

                if(name.equals("") || author.equals("") || rating.equals("")){
                    JOptionPane.showMessageDialog(Main.frame.registrationWindow,"ENTER ALL!!!");
                }else {
                    Books book=new Books(null,name,author,rating);
                    PackageData pd=new PackageData("ADD",book);
                    Main.connect(pd);
                    JOptionPane.showMessageDialog(Main.frame.addBookWindow,"Book Added");
                }


                nameText.setText("");
                authorText.setText("");
                ratingText.setText("");
            }
        });
        add(addButton);

///back
        backButton=new JButton("Back");
        backButton.setFont (backButton.getFont ().deriveFont (20.0f));
        backButton.setBounds(250,360,270,40);
        backButton.setBackground(Color.DARK_GRAY);
        backButton.setForeground(Color.decode("#FFCC33"));
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Main.frame.addBookWindow.setVisible(false);
                Main.frame.adminMenuWindow.setVisible(true);
            }
        });
        add(backButton);


    }

}
