package kz.arsen;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;

public class BookTableModel extends AbstractTableModel {
    private int columnCount=4;
    private ArrayList<String[]> dataArrayList;

    public BookTableModel(){
        dataArrayList=new ArrayList<String[]>();
        for(int i=0; i<dataArrayList.size(); i++){
            dataArrayList.add(new String[getColumnCount()]);
        }
    }

    @Override
    public int getRowCount(){
        return dataArrayList.size();
    }

    @Override
    public String getColumnName(int columnIndex){
        switch (columnIndex){
            case 0: return "id";
            case 1: return "name";
            case 2: return "author";
            case 3: return "genre";
        }
        return "";
    }

    @Override
    public int getColumnCount(){
        return columnCount;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex){
        String []rows=dataArrayList.get(rowIndex);
        return rows[columnIndex];
    }

    public void addData(String []row){
        String []rowTable=new String[getColumnCount()];
        rowTable=row;
        dataArrayList.add(rowTable);
    }


}
