package kz.arsen;

import java.io.ObjectInputStream;
import java.io.*;
import java.net.Socket;
import java.util.*;

public class ServerThread extends Thread{
    private Socket socket;

    public ServerThread(Socket socket) {
        this.socket = socket;
    }

    public void run(){
        try {
            DBManager manager = new DBManager();
            manager.connect();

            ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());

            PackageData packageData = null;
            while ( (packageData=(PackageData)inputStream.readObject())!=null){
                if(packageData.getOperationType().equals("Reg")){/// "ADD", Student
                    Client clientFromClient = packageData.getClient();
                    manager.addClient(clientFromClient);
                }
                else if(packageData.getOperationType().equals("ADD")){
                    Books bookFromAdmin=packageData.getBook();
                    manager.addBook(bookFromAdmin);
                }
                else if(packageData.getOperationType().equals("LIST")){
                    ArrayList<Client> infoForClient = manager.getAllClients();
                    PackageData toClient = new PackageData(infoForClient);
                    outputStream.writeObject(toClient);
                }
                else if(packageData.getOperationType().equals("LISTBOOK")){
                    ArrayList<Books> infoForClient = manager.getAllBooks();
                    PackageData toClient = new PackageData(infoForClient,"");
                    outputStream.writeObject(toClient);
                }
                else if(packageData.getOperationType().equals("DELETE")){
                    Integer idFromClient=packageData.getId();
                    manager.deleteClient(idFromClient);
                }
                else if(packageData.getOperationType().equals("DELETEBOOK")){
                    Integer idFromClient=packageData.getId();
                    manager.deleteBook(idFromClient);
                }
                else if(packageData.getOperationType().equals("LOGIN")){
                    String loginFromClient=packageData.getLogin();
                    String passwordFromClient=packageData.getPassword();
                    boolean infoCheckForClient=manager.checkLogin(loginFromClient,passwordFromClient);
                    PackageData checkToClient=new PackageData(infoCheckForClient);
                    outputStream.writeObject(checkToClient);
                }
            }

            inputStream.close();
            outputStream.close();
            socket.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
