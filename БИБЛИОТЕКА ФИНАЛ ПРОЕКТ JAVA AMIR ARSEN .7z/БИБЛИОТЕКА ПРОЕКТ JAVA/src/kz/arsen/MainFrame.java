package kz.arsen;


import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {
    public static MainMenu menuWindow;
    public static AdminLogin adminloginWindow;
    public static Login loginWindow;
    public static Registration registrationWindow;
    public static SearchBook searchBookWindow;
    public static ReadOnline readOnlineWindow;
    public static AdminMenu adminMenuWindow;
    public static DeleteWithId deleteWithIdWindow;
    public static JTableClients tableClientsWindow;
    public static BookMenu bookMenuWindow;
    public static AddBook addBookWindow;
    public static JTableBooks tableBooksWindow;
    public static JTableBooksForClient tableBooksForClientWindow;
    public static DeleteBooksId deleteBooksIdWindow;

    public MainFrame(){
        getContentPane().setBackground( Color.decode("#808080") );
        setSize(800,800);
        setTitle("LIBRARY KZO TDK");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        menuWindow=new MainMenu();
        menuWindow.setLocation(0,0);
        add(menuWindow);

        adminloginWindow=new AdminLogin();
        adminloginWindow.setLocation(0,0);
        adminloginWindow.setVisible(false);
        add(adminloginWindow);

        loginWindow=new Login();
        loginWindow.setLocation(0,0);
        loginWindow.setVisible(false);
        add(loginWindow);

        registrationWindow=new Registration();
        registrationWindow.setLocation(0,0);
        registrationWindow.setVisible(false);
        add(registrationWindow);

        searchBookWindow=new SearchBook();
        searchBookWindow.setLocation(0,0);
        searchBookWindow.setVisible(false);
        add(searchBookWindow);

        readOnlineWindow=new ReadOnline();
        readOnlineWindow.setLocation(0,0);
        readOnlineWindow.setVisible(false);
        add(readOnlineWindow);

        adminMenuWindow=new AdminMenu();
        adminMenuWindow.setLocation(0,0);
        adminMenuWindow.setVisible(false);
        add(adminMenuWindow);

        deleteWithIdWindow=new DeleteWithId();
        deleteWithIdWindow.setLocation(0,0);
        deleteWithIdWindow.setVisible(false);
        add(deleteWithIdWindow);

        tableClientsWindow=new JTableClients();
        tableClientsWindow.setLocation(0,0);
        tableClientsWindow.setVisible(false);
        add(tableClientsWindow);

       bookMenuWindow=new BookMenu();
       bookMenuWindow.setLocation(0,0);
       bookMenuWindow.setVisible(false);
        add(bookMenuWindow);

        addBookWindow=new AddBook();
        addBookWindow.setLocation(0,0);
        addBookWindow.setVisible(false);
        add(addBookWindow);

        tableBooksWindow=new JTableBooks();
        tableBooksWindow.setLocation(0,0);
        tableBooksWindow.setVisible(false);
        add(tableBooksWindow);


       tableBooksForClientWindow=new JTableBooksForClient();
       tableBooksForClientWindow.setLocation(0,0);
       tableBooksForClientWindow.setVisible(false);
        add(tableBooksForClientWindow);

        deleteBooksIdWindow=new DeleteBooksId();
        deleteBooksIdWindow.setLocation(0,0);
        deleteBooksIdWindow.setVisible(false);
        add(deleteBooksIdWindow);







    }


}
