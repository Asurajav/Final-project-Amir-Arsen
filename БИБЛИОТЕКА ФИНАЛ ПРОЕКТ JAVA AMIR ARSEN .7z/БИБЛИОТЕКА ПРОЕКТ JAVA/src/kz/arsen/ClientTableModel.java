package kz.arsen;
import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.util.ArrayList;

public class ClientTableModel extends AbstractTableModel {


    private int columnCount=6;
    private ArrayList<String[]> dataArrayList;

    public ClientTableModel(){
        dataArrayList=new ArrayList<String[]>();
        for(int i=0; i<dataArrayList.size(); i++){
         dataArrayList.add(new String[getColumnCount()]);
        }
    }

    @Override
    public int getRowCount(){
        return dataArrayList.size();
    }

    @Override
    public String getColumnName(int columnIndex){
        switch (columnIndex){
            case 0: return "id";
            case 1: return "name";
            case 2: return "surname";
            case 3: return "login";
            case 4: return "password";
            case 5: return "email";
        }
        return "";
    }

    @Override
    public int getColumnCount(){
        return columnCount;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex){
        String []rows=dataArrayList.get(rowIndex);
        return rows[columnIndex];
    }

    public void addData(String []row){
        String []rowTable=new String[getColumnCount()];
        rowTable=row;
        dataArrayList.add(rowTable);
    }
}
