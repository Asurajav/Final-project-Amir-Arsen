package kz.arsen;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;

public class BookMenu extends Container {
    private JButton listBookButton;
    private JButton searchBookButton;
    private JButton backButton;
    private JButton exitButton;

    public BookMenu(){
        setSize(500,600);
        setLayout(null);

        listBookButton=new JButton("LIST BOOKS");
        listBookButton.setFont (listBookButton.getFont ().deriveFont (20.0f));
        listBookButton.setBounds(200, 60, 300, 40);
        listBookButton.setBackground(Color.DARK_GRAY);
        listBookButton.setForeground(Color.decode("#FFCC33"));

        listBookButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                Main.frame.tableBooksForClientWindow.setVisible(true);
                Main.frame.bookMenuWindow.setVisible(false);
            }
        });

        add(listBookButton);


       searchBookButton=new JButton("SEARCH BOOK");
        searchBookButton.setFont (searchBookButton.getFont ().deriveFont (20.0f));
       searchBookButton.setBounds(180, 110, 300, 40);
       searchBookButton.setBackground(Color.DARK_GRAY);
       searchBookButton.setForeground(Color.decode("#FFCC33"));

       searchBookButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){

            }
        });

        add(searchBookButton);

        backButton=new JButton("BACK");
        backButton.setFont (backButton.getFont ().deriveFont (20.0f));
        backButton.setBounds(160, 160, 300, 40);
        backButton.setBackground(Color.DARK_GRAY);
        backButton.setForeground(Color.decode("#FFCC33"));

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
             Main.frame.loginWindow.setVisible(true);
             Main.frame.bookMenuWindow.setVisible(false);
            }
        });

        add(backButton);


        exitButton=new JButton("EXIT");
        exitButton.setFont (exitButton.getFont ().deriveFont (20.0f));
        exitButton.setBounds(140,210,300,40);
        exitButton.setBackground(Color.DARK_GRAY);
        exitButton.setForeground(Color.decode("#FFCC33"));

        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                System.exit(0);
            }
        });
        add(exitButton);

    }



}
