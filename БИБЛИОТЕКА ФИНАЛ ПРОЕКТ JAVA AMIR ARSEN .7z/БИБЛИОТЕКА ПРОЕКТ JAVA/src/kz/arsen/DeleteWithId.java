package kz.arsen;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;

public class DeleteWithId extends Container {
    private JLabel enterIdLabel;
    private JLabel titleLabel;

    private JTextField idPlaceText;

    private JButton enterButton;
    private JButton backButton;

    public DeleteWithId(){
        setSize(800,800);
        setLayout(null);

        titleLabel=new JLabel("DELETE BOOK PAGE");
        titleLabel.setBounds(190,50,500,40);
        titleLabel.setFont (titleLabel.getFont ().deriveFont (40.0f));
        titleLabel.setForeground(Color.decode("#FFCC33"));
        add(titleLabel);

        enterIdLabel =new JLabel("Enter ID");
        enterIdLabel.setFont (enterIdLabel.getFont ().deriveFont (20.0f));
        enterIdLabel.setBounds(250,110,110,40);
        enterIdLabel.setForeground(Color.DARK_GRAY);
        add(enterIdLabel);


        idPlaceText =new JTextField();
        idPlaceText.setBounds(360,110,150,40);
        idPlaceText.setFont (idPlaceText.getFont ().deriveFont (20.0f));
        idPlaceText.setBackground(Color.DARK_GRAY);
        idPlaceText.setForeground(Color.decode("#FFCC33"));
        idPlaceText.setCaretColor(Color.RED);
        add(idPlaceText);


        enterButton=new JButton("Enter");
        enterButton.setFont (enterButton.getFont ().deriveFont (20.0f));
        enterButton.setBounds(250,160,300,40);
        enterButton.setBackground(Color.DARK_GRAY);
        enterButton.setForeground(Color.decode("#FFCC33"));
        enterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Integer id = Integer.valueOf(idPlaceText.getText());
                if(idPlaceText.getText().equals("")){
                    JOptionPane.showMessageDialog(Main.frame.deleteWithIdWindow,"ENTER ID PlEASE!!!");
                }
            PackageData pd =new PackageData("DELETE",id);
            Main.connect(pd);

            idPlaceText.setText("");
                JOptionPane.showMessageDialog(Main.frame.deleteWithIdWindow,"SUCCESS");
            }
        });
        add(enterButton);

        backButton=new JButton("Back");
        backButton.setFont (backButton.getFont ().deriveFont (20.0f));
        backButton.setBounds(250,210,300,40);
        backButton.setBackground(Color.DARK_GRAY);
        backButton.setForeground(Color.decode("#FFCC33"));

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Main.frame.adminMenuWindow.setVisible(true);
                Main.frame.deleteWithIdWindow.setVisible(false);
            }
        });
        add(backButton);




    }

}
