package kz.arsen;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Login extends Container {
    private JLabel loginLabel;
    private JLabel passwordLabel;
    private JLabel titleLabel;

    private JTextField loginText;
    private JPasswordField passwordText;


    private JButton enterButton;
    private JButton backButton;
        //setBackground(Color.DARK_GRAY);
        //setForeground(Color.decode("#FFCC33"));
    public Login(){
        setSize(800,800);
        setLayout(null);

        titleLabel=new JLabel("LOGIN PAGE");
        titleLabel.setBounds(300,50,300,100);
        titleLabel.setFont (titleLabel.getFont ().deriveFont (40.0f));
        titleLabel.setForeground(Color.decode("#FFCC33"));
        add(titleLabel);

        loginLabel =new JLabel("Login");
        loginLabel.setFont (loginLabel.getFont ().deriveFont (20.0f));
        loginLabel.setBounds(250,230,70,40);
        loginLabel.setForeground(Color.DARK_GRAY);
        add(loginLabel);


        loginText =new JTextField();
        loginText.setBounds(320,230,200,40);
        loginText.setFont (loginText.getFont ().deriveFont (20.0f));
        loginText.setBackground(Color.DARK_GRAY);
        loginText.setForeground(Color.decode("#FFCC33"));
        loginText.setCaretColor(Color.RED);
        add(loginText);


        passwordLabel=new JLabel("Password");
        passwordLabel.setFont (passwordLabel.getFont ().deriveFont (20.0f));
        passwordLabel.setBounds(220,280,100,40);
        passwordLabel.setForeground(Color.DARK_GRAY);
        add(passwordLabel);

        passwordText =new JPasswordField();
        passwordText.setBounds(320,280,200,40);
        passwordText.setFont (passwordText.getFont ().deriveFont (20.0f));
        passwordText.setBackground(Color.DARK_GRAY);
        passwordText.setForeground(Color.decode("#FFCC33"));
        passwordText.setCaretColor(Color.RED);
        add(passwordText);


        enterButton=new JButton("Enter");
        enterButton.setFont (enterButton.getFont ().deriveFont (20.0f));
        enterButton.setBounds(250,330,270,40);
        enterButton.setBackground(Color.DARK_GRAY);
        enterButton.setForeground(Color.decode("#FFCC33"));

        enterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String login=loginText.getText();
                String password=passwordText.getText();

                PackageData pd=new PackageData("LOGIN",login,password);
                Main.connect(pd);
                /// Проверяем в базе данных есть ли такие логин и пароль потом егер болса киргиземиз
                // болмаса ошибка шыгару керек

                loginText.setText("");
                passwordText.setText("");
            }
        });
        add(enterButton);

        backButton=new JButton("Back");
        backButton.setFont (backButton.getFont ().deriveFont (20.0f));
        backButton.setBounds(250,380,270,40);
        backButton.setBackground(Color.DARK_GRAY);
        backButton.setForeground(Color.decode("#FFCC33"));

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Main.frame.menuWindow.setVisible(true);
                Main.frame.loginWindow.setVisible(false);
            }
        });
        add(backButton);




    }


}
