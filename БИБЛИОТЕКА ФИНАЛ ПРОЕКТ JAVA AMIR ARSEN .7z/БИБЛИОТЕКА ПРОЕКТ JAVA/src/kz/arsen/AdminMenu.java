package kz.arsen;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;


public class AdminMenu extends Container {
    private JButton deleteButton;
    private JButton listClientButton;
    private JButton backButton;
    private JButton addBookButton;
    private JButton listBookButton;
    private JButton deleteBookButton;

    private JLabel titleLabel;



    public AdminMenu(){
        setSize(800,800);
        setLayout(null);


        titleLabel=new JLabel("ADMIN PAGE");
        titleLabel.setBounds(300,10,300,40);
        titleLabel.setFont (titleLabel.getFont ().deriveFont (40.0f));
        titleLabel.setForeground(Color.decode("#FFCC33"));
        add(titleLabel);

        deleteButton=new JButton("DELETE CLIENTS WITH ID");
        deleteButton.setFont (deleteButton.getFont ().deriveFont (20.0f));
        deleteButton.setBounds(250, 80, 300, 40);
        deleteButton.setBackground(Color.DARK_GRAY);
        deleteButton.setForeground(Color.decode("#FFCC33"));

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                Main.frame.adminMenuWindow.setVisible(false);
                Main.frame.deleteWithIdWindow.setVisible(true);
            }
        });
        add(deleteButton);


        listClientButton=new JButton("LIST CLIENTS");
        listClientButton.setFont (listClientButton.getFont ().deriveFont (20.0f));
        listClientButton.setBounds(250, 130, 300, 40);
        listClientButton.setBackground(Color.DARK_GRAY);
        listClientButton.setForeground(Color.decode("#FFCC33"));

        listClientButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){

                Main.frame.tableClientsWindow.setVisible(true);
                Main.frame.adminMenuWindow.setVisible(false);


            }
        });
        add(listClientButton);



       addBookButton=new JButton("ADD BOOK");
        addBookButton.setFont (addBookButton.getFont ().deriveFont (20.0f));
       addBookButton.setBounds(250, 180, 300, 40);
       addBookButton.setBackground(Color.DARK_GRAY);
       addBookButton.setForeground(Color.decode("#FFCC33"));

       addBookButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                Main.frame.addBookWindow.setVisible(true);
                Main.frame.adminMenuWindow.setVisible(false);
            }
        });
        add(addBookButton);


       listBookButton=new JButton("LIST BOOK");
        listBookButton.setFont (listBookButton.getFont ().deriveFont (20.0f));
       listBookButton.setBounds(250, 230, 300, 40);
       listBookButton.setBackground(Color.DARK_GRAY);
       listBookButton.setForeground(Color.decode("#FFCC33"));

       listBookButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                Main.frame.tableBooksWindow.setVisible(true);
                Main.frame.adminMenuWindow.setVisible(false);

            }
        });
        add(listBookButton);


      deleteBookButton=new JButton("DELETE BOOK WITH ID");
        deleteBookButton.setFont (deleteBookButton.getFont ().deriveFont (20.0f));
      deleteBookButton.setBounds(250, 280, 300, 40);
      deleteBookButton.setBackground(Color.DARK_GRAY);
      deleteBookButton.setForeground(Color.decode("#FFCC33"));

      deleteBookButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                Main.frame.deleteBooksIdWindow.setVisible(true);
                Main.frame.adminMenuWindow.setVisible(false);
            }
        });
        add(deleteBookButton);



        backButton=new JButton("BACK");
        backButton.setFont (backButton.getFont ().deriveFont (20.0f));
        backButton.setBounds(250, 330, 300, 40);
        backButton.setBackground(Color.DARK_GRAY);
        backButton.setForeground(Color.decode("#FFCC33"));

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                Main.frame.adminMenuWindow.setVisible(false);
                Main.frame.adminloginWindow.setVisible(true);
            }
        });

        add(backButton);





    }
}

