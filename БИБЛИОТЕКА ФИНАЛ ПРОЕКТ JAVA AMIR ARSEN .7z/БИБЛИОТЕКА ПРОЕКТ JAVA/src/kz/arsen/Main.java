package kz.arsen;

import javax.swing.*;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Array;
import java.net.Socket;
import java.util.ArrayList;

public class Main {

    public static MainFrame frame;

    public static void connect (PackageData pd){
       try{
           Socket socket=new Socket("127.0.0.1",8888);
           ObjectOutputStream outputStream=new ObjectOutputStream(socket.getOutputStream());
           ObjectInputStream inputStream=new ObjectInputStream(socket.getInputStream());

           if(pd.getOperationType().equals("Reg")){
               outputStream.writeObject(pd);///Reg Client
           }
           else if(pd.getOperationType().equals("LIST")){
               outputStream.writeObject(pd);
               PackageData infoFromServer=(PackageData)inputStream.readObject();
               ArrayList<Client> arrayListFromServer=infoFromServer.getClients();
              /* ClientTableModel ctm=new ClientTableModel();*/

                   for(int i=0; i<arrayListFromServer.size(); i++){
                       String[] rowFromMain=new String[6];
                       rowFromMain[0]= String.valueOf(arrayListFromServer.get(i).getId());
                       rowFromMain[1]=arrayListFromServer.get(i).getName();
                       rowFromMain[2]=arrayListFromServer.get(i).getSurname();
                       rowFromMain[3]=arrayListFromServer.get(i).getLogin();
                       rowFromMain[4]=arrayListFromServer.get(i).getPassword();
                       rowFromMain[5]=arrayListFromServer.get(i).getEmail();

                       pd.getClientTableModel().addData(rowFromMain);
                   }

              /* String s="";

               for(int i=0; i<arrayListFromServer.size(); i++){
                   s+=arrayListFromServer.get(i)+"\n";
               }


               AdminMenu.listClientText.append(s);*/

           }
           else if(pd.getOperationType().equals("LISTBOOK")){
               outputStream.writeObject(pd);
               PackageData infoFromServer=(PackageData)inputStream.readObject();
               ArrayList<Books> arrayListFromServer=infoFromServer.getBookss();

               for(int i=0; i<arrayListFromServer.size(); i++){
                   String[] rowFromMain=new String[4];
                   rowFromMain[0]= String.valueOf(arrayListFromServer.get(i).getId());
                   rowFromMain[1]=arrayListFromServer.get(i).getName();
                   rowFromMain[2]=arrayListFromServer.get(i).getAuthor();
                   rowFromMain[3]=arrayListFromServer.get(i).getRating();

                   pd.getBookTableModel().addData(rowFromMain);
               }


           }
           else if(pd.getOperationType().equals("DELETE")){
                 outputStream.writeObject(pd);
           }
           else if(pd.getOperationType().equals("DELETEBOOK")){
               outputStream.writeObject(pd);
           }
           else if(pd.getOperationType().equals("ADD")){
               outputStream.writeObject(pd);

           }
           else if(pd.getOperationType().equals("LOGIN")){
               outputStream.writeObject(pd);
               PackageData infoFromServer=(PackageData)inputStream.readObject();
               boolean boolFromServer=infoFromServer.isInfoCheckForClient();

               if(boolFromServer){
                   Main.frame.loginWindow.setVisible(false);
                   Main.frame.bookMenuWindow.setVisible(true);

               }else {
                   JOptionPane.showMessageDialog(Main.frame.loginWindow,"Нет такого Пользователя");

               }
           }

          inputStream.close();
           outputStream.close();
           socket.close();


       }catch (Exception e){
           e.printStackTrace();

       }
    }
    public static void connect(){

    }

    public static void main(String[] args) {
        frame=new MainFrame();
        frame.setVisible(true);


    }
}
