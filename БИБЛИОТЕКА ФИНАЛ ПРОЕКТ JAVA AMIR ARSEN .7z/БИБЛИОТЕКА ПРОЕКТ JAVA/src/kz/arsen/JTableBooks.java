package kz.arsen;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class JTableBooks extends Container {
    private JTable clientTable;



    private JButton backButton;
    private JButton listBookButton;




    public JTableBooks(){
        setSize(800,800);
        setLayout(null);


        BookTableModel btm=new BookTableModel();
        clientTable=new JTable(btm);
        JScrollPane bookTableScrollPage=new JScrollPane(clientTable);
        bookTableScrollPage.setSize(750,600);
        add(bookTableScrollPage);



        listBookButton=new JButton("LIST BOOKS");
        listBookButton.setFont (listBookButton.getFont ().deriveFont (20.0f));
        listBookButton.setBounds(250, 620, 300, 40);
        listBookButton.setBackground(Color.DARK_GRAY);
        listBookButton.setForeground(Color.decode("#FFCC33"));

        listBookButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){

                PackageData pd = new PackageData("LISTBOOK",btm);
                Main.connect(pd);

            }
        });

        add(listBookButton);


        backButton=new JButton("BACK");
        backButton.setFont (backButton.getFont ().deriveFont (20.0f));
        backButton.setBounds(250, 670, 300, 40);
        backButton.setBackground(Color.DARK_GRAY);
        backButton.setForeground(Color.decode("#FFCC33"));

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                Main.frame.tableBooksWindow.setVisible(false);
                Main.frame.adminMenuWindow.setVisible(true);
            }
        });
        add(backButton);


    }
}
