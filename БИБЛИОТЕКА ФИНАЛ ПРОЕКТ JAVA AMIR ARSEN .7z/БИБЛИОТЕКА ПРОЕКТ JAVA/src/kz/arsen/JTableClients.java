package kz.arsen;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.util.ArrayList;

public class JTableClients extends Container {
      private JTable clientTable;



      private JButton backButton;
      private JButton listClientButton;



    public JTableClients(){
        setSize(800,800);
        setLayout(null);


        ClientTableModel ctm=new ClientTableModel();
        clientTable=new JTable(ctm);
        JScrollPane clientTableScrollPage=new JScrollPane(clientTable);
        clientTableScrollPage.setSize(750,600);
        add(clientTableScrollPage);



        listClientButton=new JButton("LIST CLIENTS");
        listClientButton.setFont (listClientButton.getFont ().deriveFont (20.0f));
        listClientButton.setBounds(250, 620, 300, 40);
        listClientButton.setBackground(Color.DARK_GRAY);
        listClientButton.setForeground(Color.decode("#FFCC33"));

        listClientButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){

                PackageData pd = new PackageData("LIST",ctm);
                Main.connect(pd);

            }
        });

        add(listClientButton);


        backButton=new JButton("BACK");
        backButton.setFont (backButton.getFont ().deriveFont (20.0f));
        backButton.setBounds(250, 670, 300, 40);
        backButton.setBackground(Color.DARK_GRAY);
        backButton.setForeground(Color.decode("#FFCC33"));

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){

                Main.frame.tableClientsWindow.setVisible(false);
                Main.frame.adminMenuWindow.setVisible(true);


            }
        });

        add(backButton);
    }
}
